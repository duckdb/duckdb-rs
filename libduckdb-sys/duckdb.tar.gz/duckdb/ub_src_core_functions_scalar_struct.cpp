#include "src/core_functions/scalar/struct/struct_pack.cpp"

#include "src/core_functions/scalar/struct/struct_insert.cpp"

