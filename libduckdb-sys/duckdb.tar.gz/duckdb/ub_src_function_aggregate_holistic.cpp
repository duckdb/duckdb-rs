#include "src/function/aggregate/holistic/quantile.cpp"

#include "src/function/aggregate/holistic/mode.cpp"

#include "src/function/aggregate/holistic/approximate_quantile.cpp"

#include "src/function/aggregate/holistic/reservoir_quantile.cpp"

