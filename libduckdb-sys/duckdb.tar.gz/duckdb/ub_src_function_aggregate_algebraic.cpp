#include "src/function/aggregate/algebraic/avg.cpp"

#include "src/function/aggregate/algebraic/covar.cpp"

#include "src/function/aggregate/algebraic/stddev.cpp"

#include "src/function/aggregate/algebraic/corr.cpp"

