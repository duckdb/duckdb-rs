#include "src/function/scalar/enum/enum_functions_implementation.cpp"

