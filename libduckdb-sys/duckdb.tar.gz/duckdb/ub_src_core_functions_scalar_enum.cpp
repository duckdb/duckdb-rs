#include "src/core_functions/scalar/enum/enum_functions.cpp"

