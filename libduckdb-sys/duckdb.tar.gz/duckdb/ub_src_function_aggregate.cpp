#include "src/function/aggregate/algebraic_functions.cpp"

#include "src/function/aggregate/distributive_functions.cpp"

#include "src/function/aggregate/holistic_functions.cpp"

#include "src/function/aggregate/nested_functions.cpp"

#include "src/function/aggregate/regression_functions.cpp"

#include "src/function/aggregate/sorted_aggregate_function.cpp"

