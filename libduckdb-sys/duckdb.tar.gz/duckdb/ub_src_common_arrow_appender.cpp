#include "src/common/arrow/appender/bool_data.cpp"

#include "src/common/arrow/appender/struct_data.cpp"

#include "src/common/arrow/appender/union_data.cpp"

