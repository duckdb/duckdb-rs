#include "src/storage/statistics/base_statistics.cpp"

#include "src/storage/statistics/column_statistics.cpp"

#include "src/storage/statistics/distinct_statistics.cpp"

#include "src/storage/statistics/list_statistics.cpp"

#include "src/storage/statistics/numeric_statistics.cpp"

#include "src/storage/statistics/segment_statistics.cpp"

#include "src/storage/statistics/string_statistics.cpp"

#include "src/storage/statistics/struct_statistics.cpp"

#include "src/storage/statistics/validity_statistics.cpp"

