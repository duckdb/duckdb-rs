#include "src/function/aggregate/distributive/approx_count.cpp"

#include "src/function/aggregate/distributive/bitagg.cpp"

#include "src/function/aggregate/distributive/count.cpp"

#include "src/function/aggregate/distributive/first.cpp"

#include "src/function/aggregate/distributive/minmax.cpp"

#include "src/function/aggregate/distributive/string_agg.cpp"

#include "src/function/aggregate/distributive/sum.cpp"

#include "src/function/aggregate/distributive/product.cpp"

#include "src/function/aggregate/distributive/bool.cpp"

#include "src/function/aggregate/distributive/arg_min_max.cpp"

#include "src/function/aggregate/distributive/skew.cpp"

#include "src/function/aggregate/distributive/kurtosis.cpp"

#include "src/function/aggregate/distributive/entropy.cpp"

