#include "src/function/scalar/list/list_lambdas.cpp"

#include "src/function/scalar/list/list_concat.cpp"

#include "src/function/scalar/list/contains_or_position.cpp"

#include "src/function/scalar/list/list_aggregates.cpp"

#include "src/function/scalar/list/array_slice.cpp"

#include "src/function/scalar/list/list_extract.cpp"

#include "src/function/scalar/list/list_sort.cpp"

#include "src/function/scalar/list/list_value.cpp"

#include "src/function/scalar/list/range.cpp"

#include "src/function/scalar/list/flatten.cpp"

