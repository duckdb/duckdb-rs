#include "src/function/scalar/date/age.cpp"

#include "src/function/scalar/date/current.cpp"

#include "src/function/scalar/date/epoch.cpp"

#include "src/function/scalar/date/date_diff.cpp"

#include "src/function/scalar/date/date_part.cpp"

#include "src/function/scalar/date/date_sub.cpp"

#include "src/function/scalar/date/date_trunc.cpp"

#include "src/function/scalar/date/make_date.cpp"

#include "src/function/scalar/date/strftime.cpp"

#include "src/function/scalar/date/time_bucket.cpp"

#include "src/function/scalar/date/to_interval.cpp"

