#include "duckdb/storage/compression/chimp/algorithm/bit_reader.hpp"

namespace duckdb {

constexpr uint8_t BitReader::REMAINDER_MASKS[];
constexpr uint8_t BitReader::MASKS[];

} // namespace duckdb
