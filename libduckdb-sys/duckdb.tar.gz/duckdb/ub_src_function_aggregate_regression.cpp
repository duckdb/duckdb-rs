#include "src/function/aggregate/regression/regr_avg.cpp"

#include "src/function/aggregate/regression/regr_count.cpp"

#include "src/function/aggregate/regression/regr_slope.cpp"

#include "src/function/aggregate/regression/regr_r2.cpp"

#include "src/function/aggregate/regression/regr_sxx_syy.cpp"

#include "src/function/aggregate/regression/regr_sxy.cpp"

#include "src/function/aggregate/regression/regr_intercept.cpp"

