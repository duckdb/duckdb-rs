#include "src/function/scalar/union/union_extract.cpp"

#include "src/function/scalar/union/union_tag.cpp"

#include "src/function/scalar/union/union_value.cpp"

