#include "src/function/scalar/struct/struct_extract.cpp"

#include "src/function/scalar/struct/struct_pack.cpp"

#include "src/function/scalar/struct/struct_insert.cpp"

