#include "src/function/scalar/generic/alias.cpp"

#include "src/function/scalar/generic/constant_or_null.cpp"

#include "src/function/scalar/generic/current_setting.cpp"

#include "src/function/scalar/generic/hash.cpp"

#include "src/function/scalar/generic/least.cpp"

#include "src/function/scalar/generic/stats.cpp"

#include "src/function/scalar/generic/typeof.cpp"

