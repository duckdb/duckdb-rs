#include "src/function/scalar/variant/variant_array_length.cpp"

#include "src/function/scalar/variant/variant_bind_utils.cpp"

#include "src/function/scalar/variant/variant_comparator.cpp"

#include "src/function/scalar/variant/variant_contains.cpp"

#include "src/function/scalar/variant/variant_exists.cpp"

#include "src/function/scalar/variant/variant_extract.cpp"

#include "src/function/scalar/variant/variant_extract_string.cpp"

#include "src/function/scalar/variant/variant_keys.cpp"

#include "src/function/scalar/variant/variant_normalize.cpp"

#include "src/function/scalar/variant/variant_path_function.cpp"

#include "src/function/scalar/variant/variant_type.cpp"

#include "src/function/scalar/variant/variant_typeof.cpp"

#include "src/function/scalar/variant/variant_utils.cpp"

