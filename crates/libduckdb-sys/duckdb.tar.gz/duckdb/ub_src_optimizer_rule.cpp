#include "src/optimizer/rule/arithmetic_simplification.cpp"

#include "src/optimizer/rule/case_simplification.cpp"

#include "src/optimizer/rule/comparison_simplification.cpp"

#include "src/optimizer/rule/conjunction_simplification.cpp"

#include "src/optimizer/rule/constant_folding.cpp"

#include "src/optimizer/rule/date_part_simplification.cpp"

#include "src/optimizer/rule/date_trunc_simplification.cpp"

#include "src/optimizer/rule/distinct_aggregate_optimizer.cpp"

#include "src/optimizer/rule/distributivity.cpp"

#include "src/optimizer/rule/empty_needle_removal.cpp"

#include "src/optimizer/rule/enum_comparison.cpp"

#include "src/optimizer/rule/equal_or_null_simplification.cpp"

#include "src/optimizer/rule/in_clause_simplification_rule.cpp"

#include "src/optimizer/rule/join_dependent_filter.cpp"

#include "src/optimizer/rule/like_optimizations.cpp"

#include "src/optimizer/rule/move_constants.cpp"

#include "src/optimizer/rule/ordered_aggregate_optimizer.cpp"

#include "src/optimizer/rule/predicate_factoring.cpp"

#include "src/optimizer/rule/regex_optimizations.cpp"

#include "src/optimizer/rule/timestamp_comparison.cpp"

#include "src/optimizer/rule/constant_order_normalization.cpp"

