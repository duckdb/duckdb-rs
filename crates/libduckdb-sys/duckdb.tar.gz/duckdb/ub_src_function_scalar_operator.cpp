#include "src/function/scalar/operator/add.cpp"

#include "src/function/scalar/operator/arithmetic.cpp"

#include "src/function/scalar/operator/cast.cpp"

#include "src/function/scalar/operator/decimal_division.cpp"

#include "src/function/scalar/operator/multiply.cpp"

#include "src/function/scalar/operator/subtract.cpp"

