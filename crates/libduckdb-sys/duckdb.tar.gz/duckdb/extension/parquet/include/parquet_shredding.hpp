#pragma once

#include <string>

#include "duckdb/common/serializer/buffered_file_writer.hpp"
#include "duckdb/common/case_insensitive_map.hpp"
#include "duckdb/common/types/variant.hpp"
#include "duckdb/common/optional_ptr.hpp"
#include "duckdb/common/string.hpp"
#include "duckdb/common/types.hpp"
#include "duckdb/common/types/value.hpp"
#include "duckdb/common/unique_ptr.hpp"

namespace duckdb {

struct ShreddingType;
class ClientContext;
class Deserializer;
class Serializer;

struct ChildShreddingTypes {
public:
	ChildShreddingTypes();

public:
	ChildShreddingTypes Copy() const;

public:
	void Serialize(Serializer &serializer) const;
	static ChildShreddingTypes Deserialize(Deserializer &source);

public:
	unique_ptr<unordered_map<string, ShreddingType>> types;
};

struct ShreddingType {
public:
	ShreddingType();
	explicit ShreddingType(const LogicalType &type);

public:
	bool operator==(const ShreddingType &other) const;

public:
	ShreddingType Copy() const;

public:
	void Serialize(Serializer &serializer) const;
	static ShreddingType Deserialize(Deserializer &source);

public:
	static ShreddingType GetShreddingTypes(const Value &val, ClientContext &context);
	void AddChild(const Identifier &name, ShreddingType &&child);
	optional_ptr<const ShreddingType> GetChild(const Identifier &name) const;

public:
	bool set = false;
	LogicalType type;
	ChildShreddingTypes children;
};

} // namespace duckdb
