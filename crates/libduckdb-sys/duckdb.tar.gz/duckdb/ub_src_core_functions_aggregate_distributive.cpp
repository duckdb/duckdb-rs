#include "src/core_functions/aggregate/distributive/approx_count.cpp"

#include "src/core_functions/aggregate/distributive/arg_min_max.cpp"

#include "src/core_functions/aggregate/distributive/bitagg.cpp"

#include "src/core_functions/aggregate/distributive/bitstring_agg.cpp"

#include "src/core_functions/aggregate/distributive/bool.cpp"

#include "src/core_functions/aggregate/distributive/entropy.cpp"

#include "src/core_functions/aggregate/distributive/kurtosis.cpp"

#include "src/core_functions/aggregate/distributive/minmax.cpp"

#include "src/core_functions/aggregate/distributive/product.cpp"

#include "src/core_functions/aggregate/distributive/skew.cpp"

#include "src/core_functions/aggregate/distributive/string_agg.cpp"

#include "src/core_functions/aggregate/distributive/sum.cpp"

