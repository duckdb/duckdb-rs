#include "src/function/table/system/create_external_resource.cpp"

#include "src/function/table/system/duckdb_approx_database_count.cpp"

#include "src/function/table/system/duckdb_columns.cpp"

#include "src/function/table/system/duckdb_connection_count.cpp"

#include "src/function/table/system/duckdb_constraints.cpp"

#include "src/function/table/system/duckdb_coordinate_systems.cpp"

#include "src/function/table/system/duckdb_databases.cpp"

#include "src/function/table/system/duckdb_dependencies.cpp"

#include "src/function/table/system/duckdb_dialects.cpp"

#include "src/function/table/system/duckdb_eviction_queues.cpp"

#include "src/function/table/system/duckdb_extension_repositories.cpp"

#include "src/function/table/system/duckdb_extensions.cpp"

#include "src/function/table/system/duckdb_external_file_cache.cpp"

#include "src/function/table/system/duckdb_functions.cpp"

#include "src/function/table/system/duckdb_grammar_extensions.cpp"

#include "src/function/table/system/duckdb_indexes.cpp"

#include "src/function/table/system/duckdb_keywords.cpp"

#include "src/function/table/system/duckdb_log.cpp"

#include "src/function/table/system/duckdb_log_contexts.cpp"

#include "src/function/table/system/duckdb_memory.cpp"

#include "src/function/table/system/duckdb_metrics.cpp"

#include "src/function/table/system/duckdb_optimizers.cpp"

#include "src/function/table/system/duckdb_prepared_statements.cpp"

#include "src/function/table/system/duckdb_schemas.cpp"

#include "src/function/table/system/duckdb_secret_type_parameters.cpp"

#include "src/function/table/system/duckdb_secret_types.cpp"

#include "src/function/table/system/duckdb_secrets.cpp"

#include "src/function/table/system/duckdb_sequences.cpp"

#include "src/function/table/system/duckdb_settings.cpp"

#include "src/function/table/system/duckdb_tables.cpp"

#include "src/function/table/system/duckdb_temporary_files.cpp"

#include "src/function/table/system/duckdb_triggers.cpp"

#include "src/function/table/system/duckdb_types.cpp"

#include "src/function/table/system/duckdb_variables.cpp"

#include "src/function/table/system/duckdb_views.cpp"

#include "src/function/table/system/duckdb_which_secret.cpp"

#include "src/function/table/system/enable_profiling.cpp"

#include "src/function/table/system/external_resource_types.cpp"

#include "src/function/table/system/external_resources.cpp"

#include "src/function/table/system/logging_utils.cpp"

#include "src/function/table/system/pragma_collations.cpp"

#include "src/function/table/system/pragma_database_size.cpp"

#include "src/function/table/system/pragma_metadata_info.cpp"

#include "src/function/table/system/pragma_storage_info.cpp"

#include "src/function/table/system/pragma_table_info.cpp"

#include "src/function/table/system/pragma_table_sample.cpp"

#include "src/function/table/system/pragma_user_agent.cpp"

#include "src/function/table/system/test_all_types.cpp"

#include "src/function/table/system/test_vector_types.cpp"

