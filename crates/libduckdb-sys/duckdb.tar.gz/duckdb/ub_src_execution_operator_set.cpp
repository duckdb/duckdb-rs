#include "src/execution/operator/set/physical_cte.cpp"

#include "src/execution/operator/set/physical_recursive_cte.cpp"

#include "src/execution/operator/set/physical_recursive_cte_delta.cpp"

#include "src/execution/operator/set/physical_recursive_cte_runtime.cpp"

#include "src/execution/operator/set/physical_recursive_cte_state.cpp"

#include "src/execution/operator/set/physical_union.cpp"

