#include "extension/core_functions/scalar/struct/struct_insert.cpp"

