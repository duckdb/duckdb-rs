#include "extension/core_functions/scalar/generic/alias.cpp"

#include "extension/core_functions/scalar/generic/binning.cpp"

#include "extension/core_functions/scalar/generic/can_implicitly_cast.cpp"

#include "extension/core_functions/scalar/generic/current_setting.cpp"

#include "extension/core_functions/scalar/generic/hash.cpp"

#include "extension/core_functions/scalar/generic/least.cpp"

#include "extension/core_functions/scalar/generic/stats.cpp"

#include "extension/core_functions/scalar/generic/typeof.cpp"

#include "extension/core_functions/scalar/generic/system_functions.cpp"

