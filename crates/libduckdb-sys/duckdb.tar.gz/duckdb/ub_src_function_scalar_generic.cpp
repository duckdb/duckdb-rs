#include "src/function/scalar/generic/barrier.cpp"

#include "src/function/scalar/generic/constant_or_null.cpp"

#include "src/function/scalar/generic/error.cpp"

#include "src/function/scalar/generic/getvariable.cpp"

#include "src/function/scalar/generic/invoke.cpp"

