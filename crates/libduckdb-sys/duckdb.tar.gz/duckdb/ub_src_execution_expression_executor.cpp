#include "src/execution/expression_executor/execute_case.cpp"

#include "src/execution/expression_executor/execute_comparison.cpp"

#include "src/execution/expression_executor/execute_conjunction.cpp"

#include "src/execution/expression_executor/execute_constant.cpp"

#include "src/execution/expression_executor/execute_function.cpp"

#include "src/execution/expression_executor/execute_lambda.cpp"

#include "src/execution/expression_executor/execute_operator.cpp"

#include "src/execution/expression_executor/execute_parameter.cpp"

#include "src/execution/expression_executor/execute_reference.cpp"

