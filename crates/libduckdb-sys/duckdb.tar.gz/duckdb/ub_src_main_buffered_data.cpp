#include "src/main/buffered_data/simple_buffered_data.cpp"

