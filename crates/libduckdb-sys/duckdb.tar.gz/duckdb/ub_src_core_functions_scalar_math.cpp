#include "src/core_functions/scalar/math/numeric.cpp"

