#include "src/core_functions/scalar/list/array_slice.cpp"

#include "src/core_functions/scalar/list/flatten.cpp"

#include "src/core_functions/scalar/list/list_aggregates.cpp"

#include "src/core_functions/scalar/list/list_filter.cpp"

#include "src/core_functions/scalar/list/list_has_all.cpp"

#include "src/core_functions/scalar/list/list_has_any.cpp"

#include "src/core_functions/scalar/list/list_sort.cpp"

#include "src/core_functions/scalar/list/list_distance.cpp"

#include "src/core_functions/scalar/list/list_cosine_similarity.cpp"

#include "src/core_functions/scalar/list/list_inner_product.cpp"

#include "src/core_functions/scalar/list/list_reduce.cpp"

#include "src/core_functions/scalar/list/list_transform.cpp"

#include "src/core_functions/scalar/list/list_value.cpp"

#include "src/core_functions/scalar/list/range.cpp"

